package org.example;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.ListTopicsOptions;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.errors.TopicExistsException;

import java.util.Collections;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;

public class CreateTopic {
    public static void main(String[] args) {
        String bootstrapServers = "82.25.104.1:9092,82.25.104.1:9094";
        String topicName = "test-topic";
        int partitions = 4;
        short replicationFactor = 2; // you have 2 brokers now

        // Configure properties for Kafka Topic
        Properties properties = new Properties();
        properties.setProperty(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        properties.setProperty("security.protocol", "SASL_PLAINTEXT");
        properties.setProperty(SaslConfigs.SASL_MECHANISM, "PLAIN");
        properties.setProperty(SaslConfigs.SASL_JAAS_CONFIG,
                "org.apache.kafka.common.security.plain.PlainLoginModule required " +
                        "username=\"admin\" password=\"admin-secret\";"
        );

        // Create AdminClient
        try (AdminClient adminClient = AdminClient.create(properties)) {
            // Check if the topic exists
            ListTopicsOptions options = new ListTopicsOptions().listInternal(false);
            Set<String> topicNames = adminClient.listTopics(options).names().get();

            if (topicNames.contains(topicName)) {
                System.out.println("Topic '" + topicName + "' already exists.");
            } else {
                // Create a new topic if it doesn't exist
                NewTopic newTopic = new NewTopic(topicName, partitions, replicationFactor);

                // Create the topic in Kafka
                adminClient.createTopics(Collections.singletonList(newTopic)).all().get();

                System.out.println("Topic '" + topicName + "' created successfully with " + partitions + " partitions.");
            }
        } catch (ExecutionException | InterruptedException e) {
            if (e.getCause() instanceof TopicExistsException) {
                System.out.println("Topic '" + topicName + "' already exists.");
            } else {
                e.printStackTrace();
            }
        }
    }
}

