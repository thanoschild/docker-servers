package org.example;

import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.errors.TopicExistsException;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.*;
import java.util.concurrent.ExecutionException;

public class Producer {
    public static void main(String[] args) {
        String bootstrapServers = "82.25.104.1:9092,82.25.104.1:9094";

        // Configure properties for Kafka Producer
        Properties properties = new Properties();
        properties.setProperty(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);

        properties.setProperty("security.protocol", "SASL_PLAINTEXT");
        properties.setProperty(SaslConfigs.SASL_MECHANISM, "PLAIN");
        properties.setProperty(SaslConfigs.SASL_JAAS_CONFIG,
                "org.apache.kafka.common.security.plain.PlainLoginModule required " +
                        "username=\"admin\" password=\"admin-secret\";"
        );

        // producer properties
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", StringSerializer.class.getName());

        /**
         Not recommended to use in production
         properties.setProperty("batch.size", "400");
         properties.setProperty("partitioner.class", RoundRobinPartitioner.class.getName());
         */

        // create producer
        KafkaProducer<String, String> producer = new KafkaProducer<>(properties);

        for(int i = 0; i<10; i++) {
            // create record
            String topic = "test-topic";
            String key = "id-" + i;
            String value = "msg-" + i;

            ProducerRecord<String, String> producerRecord = new ProducerRecord<>(topic, key, value);

            // send data with callback
            producer.send(producerRecord, (metadata, exception) -> {
                // execute everytime when record send successfully sent or an exception is thrown
                if (exception == null) {
                    System.out.println("Topic name: " + metadata.topic());
                    System.out.println("key: " + key);
                    System.out.println("Partition: " + metadata.partition());
                    System.out.println("Offset: " + metadata.offset());
                    System.out.println("Timestamp: " + metadata.timestamp());
                } else {
                    exception.printStackTrace();
                }
            });
        }

        // prodcuer will send all the data and blocked until done - synchronous
        producer.flush();

        // flush and close the producer
        producer.close();
    }
}
