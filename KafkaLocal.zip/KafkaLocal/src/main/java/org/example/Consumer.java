package org.example;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;

public class Consumer {

    public static void main(String[] args) {
        String groupId = "test-group";  // Consumer group ID
        String bootstrapServers = "82.25.104.1:9092,82.25.104.1:9094";

        // Configure the properties for Kafka Consumer
        Properties properties = new Properties();
        properties.setProperty(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        properties.setProperty("security.protocol", "SASL_PLAINTEXT");
        properties.setProperty(SaslConfigs.SASL_MECHANISM, "PLAIN");
        properties.setProperty(SaslConfigs.SASL_JAAS_CONFIG,
                "org.apache.kafka.common.security.plain.PlainLoginModule required " +
                        "username=\"admin\" password=\"admin-secret\";"
        );

        properties.setProperty("key.deserializer", StringDeserializer.class.getName());
        properties.setProperty("value.deserializer", StringDeserializer.class.getName());
        properties.setProperty("group.id", groupId);
        properties.setProperty("auto.offset.reset", "earliest");  // Start consuming from the earliest available offset
        properties.setProperty("enable.auto.commit", "true"); // Auto commit offsets

        // Create the Kafka Consumer instance
        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(properties);

        // Gracefully handle shutdown
        final Thread mainThread = Thread.currentThread();
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                System.out.println("Detected shutdown, calling consumer.wakeup() to stop...");
                consumer.wakeup();
                try {
                    mainThread.join(); // Ensure main thread finishes before exiting
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        try {
            // Subscribe to the topic (the topic should exist)
            consumer.subscribe(Arrays.asList("test-topic"));

            while (true) {
                System.out.println("Polling for new records...");
                // Poll records from the Kafka topic
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(5000));  // Adjust the polling duration

                // Process each record
                for (ConsumerRecord<String, String> record : records) {
                    System.out.println("Key: " + record.key() + ", Value: " + record.value() +
                            ", Partition: " + record.partition() + ", Offset: " + record.offset());
                }
            }
        } catch (WakeupException e) {
            System.out.println("Consumer is starting to shut down.");
        } catch (Exception e) {
            System.out.println("Unexpected exception occurred in the consumer");
        } finally {
            // Ensure graceful shutdown of the consumer
            consumer.close();
            System.out.println("Consumer has been gracefully shut down.");
        }
    }
}
